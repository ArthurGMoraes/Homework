//
//  EvaApp.swift
//  Eva
//
//  Created by Student05 on 01/06/23.
//

import SwiftUI

@main
struct EvaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
