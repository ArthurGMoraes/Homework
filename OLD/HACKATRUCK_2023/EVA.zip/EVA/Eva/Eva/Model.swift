
import Foundation

struct Usuario : Codable{
    var _id : String?
    var _rev : String?
    var nome : String?
    var tema : String?
    var intervalo : String?
    var caixinha_state : Bool?
    var portugues : Bool?
}
