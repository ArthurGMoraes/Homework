import Foundation

struct Noticias : Codable{
    var _id : String?
    var _rev : String?
    var titulo : String?
    var data : String?
    var descricao : String?
    var url : String?
}
